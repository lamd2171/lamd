// dummy.cpp
#include <jni.h>
void dummy_function() {}
